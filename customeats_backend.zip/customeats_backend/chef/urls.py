from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('login', views.chef_login, name='chef_login'),
    path('homepage', views.chef_homepage, name='chef_homepage'),
    path('confirm_logout', views.chef_logout, name='chef_logout'),  # Logout confirmation screen
    path('logout', auth_views.LogoutView.as_view(next_page='chef_login'), name='logout'),  # Actual logout path
    # path('orders', views.create_order, name='create_order'),
    path('incoming_orders/', views.incoming_orders, name='incoming_orders'),
    
            ]

