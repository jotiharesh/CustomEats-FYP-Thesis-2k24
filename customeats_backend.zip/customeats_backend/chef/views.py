from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
# from .models import Order  
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from api.models import Order

def chef_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Check if the username is 'chef' (or another chef-specific username)
        if username == 'chef':  # Ensure that only chef credentials are used
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('chef_homepage')  # Redirect to chef's homepage upon successful login
            else:
                messages.error(request, "Invalid credentials for chef")
        else:
            messages.error(request, "Invalid username for chef")
    return render(request, 'chef_login.html')

def chef_logout(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Ensure only chef can log out
        if username == 'chef':  # Check if it's the chef logging out
            user = authenticate(request, username=username, password=password)
            if user is not None:
                logout(request)  # Log the user out
                return redirect('chef_login')  # Redirect to login page after logout
            else:
                messages.error(request, "Invalid username or password for chef")
        else:
            messages.error(request, "You are not authorized to log out.")
    
    return render(request, 'chef_logout.html')

# def chef_homepage(request):
#    return render(request, 'homepage.html')

def chef_homepage(request):
    orders = Order.objects.all().values()  # Fetch orders
    orders_list = list(orders)  # Convert to a list
    return render(request, 'homepage.html', {'orders_json': orders_list})

# def chef_homepage(request):
#     # Fetch orders from the database (you can filter or modify the query as needed)
#     orders = Order.objects.all().values(
#         "order_id", "table_no", "oiltype", "protein",
#         "ricetype", "sidedish", "extraingredients", "spicelevel",
#         "specialinstructions", "total_price", "orderstatus", "created_at"
#     )
    
#     # Convert to a list of dictionaries
#     orders_list = list(orders)

#     # Pass the orders to the template
#     return render(request, 'homepage.html', {'orders_json': orders_list})

def incoming_orders(request):
    try:
        # Fetch orders and include customizations
        orders = Order.objects.values(
            "order_id", "table_no", "oiltype", "protein",
            "ricetype", "sidedish", "extraingredients", "spicelevel",
            "specialinstructions", "total_price", "orderstatus", "created_at"
        )
        # print(orders)  # Log the orders data
        return JsonResponse({"orders": list(orders)}, safe=False)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

    
# def chef_homepage(request):
#     # Fetch all orders
#     orders = Order.objects.all().order_by('-id')  # Fetch in reverse order for latest orders first
#     return render(request, 'homepage.html', {'orders': orders})

# def chef_homepage(request):
#     # Fetch orders from the database, filter by status if needed
#     orders = Order.objects.all()  # You can filter by status if required, e.g., Order.objects.filter(status='new')

#     # Pass the orders to the template
#     return render(request, 'homepage.html', {'orders': orders})

# def create_order(request):
#     if request.method == 'POST':
#         try:
#             data = json.loads(request.body)

#             # Extract data from the request
#             order_id = data.get('order_id', 'Unknown')
#             total = data.get('total', 0)
#             table_number = data.get('table_number', 'Unknown')
#             customizations = data.get('customizations', 'No customizations')

#             # Log the order details (for now)
#             print(f"New Order Received!")
#             print(f"Order ID: {order_id}")
#             print(f"Total: {total}")
#             print(f"Table Number: {table_number}")
#             print(f"Customizations: {customizations}")

#             # TODO: Save order to database if required

#             return JsonResponse({'message': 'Order received successfully!'}, status=201)
#         except json.JSONDecodeError:
#             return JsonResponse({'error': 'Invalid JSON'}, status=400)
#     return JsonResponse({'error': 'Invalid HTTP method'}, status=405)




