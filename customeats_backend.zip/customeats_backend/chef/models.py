# from django.db import models

# class Order(models.Model):
#     order_id = models.CharField(max_length=100, primary_key=True)  # Ensure it's mapped to your existing primary key
#     # customer_name = models.CharField(max_length=255)
#     table_number = models.PositiveIntegerField()
#     items = models.TextField()
#     status = models.CharField(max_length=20, default='new')
#     created_at = models.DateTimeField()
#     updated_at = models.DateTimeField()

#     class Meta:
#         db_table = 'api_order'  # Map this model to the existing 'api_order' table in the database

#     def __str__(self):
#         return f"Order {self.order_id} - {self.status}"
