# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Dinningtable(models.Model):
    table_no = models.CharField(max_length=200)
    auth_code = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'dinningtable'


class Extraingredients(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'extraingredients'


class Menutable(models.Model):
    item_name = models.CharField(max_length=200)
    image = models.CharField(max_length=200)
    price = models.FloatField()

    class Meta:
        managed = False
        db_table = 'menutable'


class Oiltype(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'oiltype'


class Protein(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'protein'


class Ricetype(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'ricetype'


class Sidedish(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'sidedish'


class Spicelevel(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'spicelevel'
