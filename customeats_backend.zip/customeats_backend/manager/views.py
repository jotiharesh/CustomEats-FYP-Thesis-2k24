from django.contrib.auth import authenticate, login, logout as auth_logout
from django.contrib import messages
from django.shortcuts import render, redirect

def manager_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Check if the username is 'admin' (or another manager-specific username)
        if username == 'admin':  # Ensure that only manager credentials are used
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'Invalid credentials for manager')
        else:
            messages.error(request, 'Invalid username for manager')
    return render(request, 'manager_login.html')

def dashboard(request):
    return render(request, 'dashboard.html')

def tables(request):
    table_data = [
        {"table_num": "table01", "availability": "booked", "auth_code": "******"},
        {"table_num": "table02", "availability": "free", "auth_code": "******"},
        {"table_num": "table03", "availability": "booked", "auth_code": "******"},
        {"table_num": "table04", "availability": "free", "auth_code": "******"},
        {"table_num": "table05", "availability": "booked", "auth_code": "******"},
    ]
    return render(request, 'tables.html', {'table_data': table_data})

def orders(request):
    order_data = [
        {"order_num": "011", "table_num": "table01", "total_item": 2, "total_quantity": 4, "sub_total": 2500, "tax": 100, "order_date": "10/11/24"},
        {"order_num": "012", "table_num": "table03", "total_item": 2, "total_quantity": 3, "sub_total": 2000, "tax": 70, "order_date": "10/11/24"},
        {"order_num": "013", "table_num": "table02", "total_item": 1, "total_quantity": 2, "sub_total": 1500, "tax": 50, "order_date": "10/11/24"},
        {"order_num": "014", "table_num": "table04", "total_item": 2, "total_quantity": 5, "sub_total": 4000, "tax": 120, "order_date": "10/11/24"},
        {"order_num": "015", "table_num": "table05", "total_item": 1, "total_quantity": 1, "sub_total": 600, "tax": 30, "order_date": "10/11/24"},
    ]
    return render(request, 'orders.html', {'order_data': order_data})

def staff(request):
    staff_data = [
        {"first_name": "Rashid", "last_name": "Khan", "phone": "03336790865", "address": "Hyderabad", "emp_id": "011", "role": "Chef", "password": "******"},
        {"first_name": "Asad", "last_name": "Rind", "phone": "03348905764", "address": "Hyderabad", "emp_id": "012", "role": "Ast.Chef", "password": "******"},
        {"first_name": "Zubair", "last_name": "Bhatti", "phone": "03126532890", "address": "Karachi", "emp_id": "013", "role": "Waiter", "password": "none"},
        {"first_name": "Mozam", "last_name": "Khan", "phone": "03007008943", "address": "Hyderabad", "emp_id": "014", "role": "Manager", "password": "******"},
        {"first_name": "Qasim", "last_name": "Iqbal", "phone": "03355577612", "address": "Karachi", "emp_id": "015", "role": "Admin", "password": "******"},
    ]
    return render(request, 'staff.html', {'staff_data': staff_data})

def inventory(request):
    inventory_data = [
        {"item_id": "01", "item_name": "Biryani", "price": 600, "image": "/img/Biryani.png", "availability": "Yes"},
        {"item_id": "02", "item_name": "Haleem", "price": 700, "image": "/img/Haleem.png", "availability": "No"},
        {"item_id": "03", "item_name": "Karhai", "price": 1000, "image": "/img/Karhai.png", "availability": "No"},
        {"item_id": "04", "item_name": "Kabab", "price": 400, "image": "/img/Kabab.png", "availability": "No"},
    ]
    return render(request, 'inventory.html', {'inventory_data': inventory_data})

def logout(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Ensure only manager can log out
        if username == 'admin':  # Check if it's the manager logging out
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_logout(request)  # Log the user out
                return redirect('manager_login')  # Redirect to login page after logout
            else:
                messages.error(request, "Invalid username or password for manager")
        else:
            messages.error(request, "You are not authorized to log out.")
    
    return render(request, 'logout.html')