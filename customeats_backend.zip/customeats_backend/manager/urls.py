from django.urls import path
from . import views

urlpatterns = [
    path('login', views.manager_login, name='manager_login'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('tables', views.tables, name='tables'),
    path('orders', views.orders, name='orders'),
    path('staff', views.staff, name='staff'),
    path('inventory', views.inventory, name='inventory'),
    path('logout', views.logout, name='logout'),


]