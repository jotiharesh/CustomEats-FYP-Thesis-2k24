from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Dinningtable, Extraingredients, Menutable, Oiltype, Protein, Ricetype, Sidedish, Spicelevel, Order
import json
import logging

logger = logging.getLogger(__name__)

# Separate views for fetching data
def dinningtable_data(request):
    data = list(Dinningtable.objects.values())
    logger.warning("You tried to login")
    logger.warning(JsonResponse(data, safe=False))
    logger.warning(f"Request: {request.method} {request.META['QUERY_STRING']}")
    return JsonResponse(data, safe=False)

def extraingredients_data(request):
    data = list(Extraingredients.objects.values())
    return JsonResponse(data, safe=False)

def menutable_data(request):
    data = list(Menutable.objects.values())
    return JsonResponse(data, safe=False)

def oiltype_data(request):
    data = list(Oiltype.objects.values())
    return JsonResponse(data, safe=False)

def protein_data(request):
    data = list(Protein.objects.values())
    return JsonResponse(data, safe=False)

def ricetype_data(request):
    data = list(Ricetype.objects.values())
    return JsonResponse(data, safe=False)

def sidedish_data(request):
    data = list(Sidedish.objects.values())
    return JsonResponse(data, safe=False)

def spicelevel_data(request):
    data = list(Spicelevel.objects.values())
    return JsonResponse(data, safe=False)

# New view to receive customizations from the Flutter app
@csrf_exempt
def save_order(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)  # Parse the incoming JSON
            table_no = data.get('table_no')
            items = data.get('items', [])
            total_price = data.get('total_price')
            payment_method = data.get('payment_method')

            for item in items:
                # Check if item is a string or dictionary
                if isinstance(item, str):
                    item_data = json.loads(item)  # Parse JSON string
                else:
                    item_data = item  # Already a dictionary

                # Extract data
                protein = item_data.get('protein')
                oiltype = item_data.get('oilType')
                ricetype = item_data.get('riceType')
                extraingredients = item_data.get('extraIngredients')
                sidedish = item_data.get('sideDish')
                spicelevel = item_data.get('spiceLevel')
                specialinstructions = item_data.get('specialInstructions', "")  # Free-text field

                # Save order
                Order.objects.create(
                    table_no=table_no,
                    protein=protein,
                    oiltype=oiltype,
                    ricetype=ricetype,
                    extraingredients=json.dumps(extraingredients),
                    sidedish=json.dumps(sidedish),
                    spicelevel=spicelevel,
                    specialinstructions=specialinstructions,
                    total_price=total_price,
                    payment_method=payment_method,
                )

            logger.warning(f"Order saved for Table {table_no}")
            return JsonResponse({"message": "Order saved successfully"}, status=200)
        except Exception as e:
            logger.error(f"Error saving order: {e}")
            return JsonResponse({"error": str(e)}, status=500)
    return JsonResponse({"message": "Invalid request"}, status=400)


