# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
import uuid

class Dinningtable(models.Model):
    table_no = models.CharField(max_length=200)
    auth_code = models.CharField(max_length=200)
    available_id= models.CharField(max_length=200)


    class Meta:
        managed = False
        db_table = 'dinningtable'


class Extraingredients(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'extraingredients'


class Menutable(models.Model):
    item_name = models.CharField(max_length=200)
    image = models.CharField(max_length=200)
    price = models.FloatField()
    availability = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'menutable'


class Oiltype(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'oiltype'


class Protein(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'protein'


class Ricetype(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'ricetype'


class Sidedish(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'sidedish'


class Spicelevel(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        managed = False
        db_table = 'spicelevel'


class Order(models.Model):
    order_id = models.AutoField(primary_key=True)  # Auto-incrementing primary key
    table_no = models.CharField(max_length=50)  # Table number
    protein = models.CharField(max_length=100, blank=True, null=True)  # Protein selection
    oiltype = models.CharField(max_length=100, blank=True, null=True)  # Oil type selection
    ricetype = models.CharField(max_length=100, blank=True, null=True)  # Rice type selection
    extraingredients = models.TextField(blank=True, null=True)  # Extra ingredients (stored as JSON string)
    sidedish = models.TextField(blank=True, null=True)  # Side dish (stored as JSON string)
    spicelevel = models.CharField(max_length=50, blank=True, null=True)  # Spice level
    orderstatus = models.CharField(max_length=50, default='Pending')  # Status of the order (default: Pending)
    created_at = models.DateTimeField(auto_now_add=True)  # Timestamp of order creation
    total_price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)  # New field
    payment_method = models.CharField(max_length=50, blank=True, null=True)  # New field
    specialinstructions = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Order #{self.order_id} - Table {self.table_no}"