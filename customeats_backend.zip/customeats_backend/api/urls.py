from django.urls import path
from . import views

urlpatterns = [
    path('dt/', views.dinningtable_data, name='dt'),
    path('dinningtable/', views.dinningtable_data, name='dinningtable_data'),
    path('extraingredients/', views.extraingredients_data, name='extraingredients_data'),
    path('menutable/', views.menutable_data, name='menutable_data'),
    path('oiltype/', views.oiltype_data, name='oiltype_data'),
    path('protein/', views.protein_data, name='protein_data'),
    path('ricetype/', views.ricetype_data, name='ricetype_data'),
    path('sidedish/', views.sidedish_data, name='sidedish_data'),
    path('spicelevel/', views.spicelevel_data, name='spicelevel_data'),
   # path('receive-customizations/', views.receive_customizations, name='receive_customizations'),
    path('save-order/', views.save_order, name='save_order'),
    
]
    
